package com.cg.oirs.controller;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.oirs.bean.User;

@Controller
public class OirsController {
	
	@RequestMapping("index")
	public String getIndexPage()
	{
		return "index";
	}
	
	@RequestMapping("admin")
	public String getAdminPage()
	{
		return "/Admin/admin_dashboard";
	}
	
	@RequestMapping("addemployee")
	public String getAddEmployeePage(Model m)
	{
		User user=new User();
		m.addAttribute("userDetails", user);
		return "/Admin/addemployee";
	}
}
